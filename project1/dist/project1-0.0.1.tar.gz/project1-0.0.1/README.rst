project1 - Package description goes here
--------------------------------------

Installation
------------

Use::

    > sudo pip install project1

or::

    > sudo easy install project1

or::

    > git clone git://github.com/ingydotnet/project1-py.git
    > cd project1-py
    > sudo make install

Usage
-----

Development Status
------------------

Community
---------

Authors
-------

* Ingy dot Net <ingy@ingy.net>

Copyright
---------

project1 is Copyright (c) 2013, Ingy dot Net

project1 is licensed under the New BSD License. See the LICENSE file.
